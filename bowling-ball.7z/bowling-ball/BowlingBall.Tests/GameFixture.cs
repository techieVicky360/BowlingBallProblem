﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        Game game;

        [TestInitialize]
        public void SetUpGame()
        {
            game = new Game();
        }

        [TestMethod]
        public void CreateGame()
        {
            game = new Game();
        }

        [TestMethod]
        public void RollGutterGame()
        {
            RollMany(20, 0);
            Assert.AreEqual(0, game.GetScore());
        }

        [TestMethod]
        public void RollOnes()
        {
            RollMany(20, 1);
            Assert.AreEqual(20, game.GetScore());
        }

        [TestMethod]
        public void RollSpareFirstFrame()
        {
            game.Roll(9);
            game.Roll(1);
            RollMany(18, 1);

            Assert.AreEqual(29, game.GetScore());
        }

        [TestMethod]
        public void RollSpareEveryFrame()
        {
            RollMany(21, 5);

            Assert.AreEqual(150, game.GetScore());
        }

        [TestMethod]
        public void RollPerfectGame()
        {
            RollMany(12, 10);

            Assert.AreEqual(300, game.GetScore());
        }

        [TestMethod]
        public void RollNineOneSpares()
        {
            for (int i = 0; i < 10; i++)
            {
                game.Roll(9); game.Roll(1);
            }

            game.Roll(9);

            Assert.AreEqual(190, game.GetScore());
        }

        [TestMethod]
        public void ActualScenario()
        {
            game.Roll(10);
            game.Roll(9);
            game.Roll(1);
            game.Roll(5);
            game.Roll(5);
            game.Roll(7);
            game.Roll(2);
            game.Roll(10);
            game.Roll(10);
            game.Roll(10);
            game.Roll(9);
            game.Roll(0);
            game.Roll(8);
            game.Roll(2);
            game.Roll(9);
            game.Roll(1);
            game.Roll(10);

            Assert.AreEqual(187, game.GetScore());
        }

        private void RollMany(int rolls, int pins)
        {
            for (int i = 0; i < rolls; i++)
            {
                game.Roll(pins);
            }
        }
    }
}
