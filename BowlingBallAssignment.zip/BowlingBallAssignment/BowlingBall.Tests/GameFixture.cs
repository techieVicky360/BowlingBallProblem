﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        readonly Game game = new Game();
        [TestMethod]
        public void CheckActualScenario()
        {
            game.RollStrike();
            game.Roll(9, 1);
            game.Roll(5, 5);
            game.Roll(7, 2);
            game.RollStrike();
            game.RollStrike();
            game.RollStrike();
            game.Roll(9, 0);
            game.Roll(8, 2);
            game.RollFinalFrame(9, 1, 10);
            Assert.AreEqual(187, game.GetScore());
        }
    }
}
