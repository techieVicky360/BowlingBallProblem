﻿using System;

namespace BowlingBall
{
    [Serializable]
    public class GameOverException : Exception
    {
        public GameOverException() { }

        public GameOverException(string message)
            : base(message) { }
    }
}
