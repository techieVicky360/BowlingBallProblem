﻿namespace BowlingBall
{
    public class Open : Frame
    {
        public Open(int firstRoll, int secondRoll) : base(firstRoll, secondRoll) { }
    }
}
